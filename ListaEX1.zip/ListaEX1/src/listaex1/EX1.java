/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;

import java.util.Scanner;

public class EX1 {
    public static void main(String[] args) {
        double nota1, nota2, media_final;
                String resultado="";
        Scanner s = new Scanner(System.in);
        
       
        System.out.println("Calculo de nota final: ");
        System.out.print("Inserir nota 1: ");
        nota1 = s.nextDouble();
        System.out.print("Inserir nota 2 ");
        nota2 = s.nextDouble();
        
        media_final = (nota1 + nota2) / 2;
        
        if (media_final >= 6)  {
            resultado = "Aprovado ";
            
        }else if (media_final >= 4) {
            resultado = "precisa fazer a prova substitutiva";
        }else {
            resultado = "Reprovado ";
        }

        System.out.printf("Média: %.2f", media_final);
        System.out.println(" - resultado: " + resultado);
     
      
    }
}