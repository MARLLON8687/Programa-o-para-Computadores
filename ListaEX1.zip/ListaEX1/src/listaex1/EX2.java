/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;

import java.util.Scanner;

public class EX2 {
    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();
        
     
        System.out.print("Digite sua idade: ");
        int idade = scanner.nextInt();
        scanner.nextLine();  
        
        
        System.out.print("Digite seu gênero: ");
        String genero = scanner.nextLine();
        
       
        System.out.print("Digite sua cor favorita: ");
        String corFavorita = scanner.nextLine();
        
        
        System.out.print("Você pratica esportes? (sim/não): ");
        String praticaEsporte = scanner.nextLine();
        
   
        System.out.println("\nInformações Digitadas:");
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Gênero: " + genero);
        System.out.println("Cor Favorita: " + corFavorita);
        System.out.println("Pratica Esportes: " + praticaEsporte);
        
       
    }
}
