/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;

import java.util.Scanner;

/**
 *
 * @author 60001928
 */
public class EX3 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        { 
        System.out.print("Digite o primeiro numero: ");
        double num1 = s.nextDouble();
        System.out.print("Digite o segundo numero: ");
        double num2 = s.nextDouble();

        double soma = num1 + num2;
        double subtracao = num1 - num2;
        double multiplicacao = num1 * num2;
        double divisao = num1 / num2;

        System.out.println("Soma: " + num1 + " + " + num2 + " = " + soma);
        System.out.println("Subtracao: " + num1 + " - " + num2 + " = " + subtracao);
        System.out.println("Multiplicacao: " + num1 + " * " + num2 + " = " + multiplicacao);
        System.out.println("Divisao: " + num1 + " / " + num2 + " = " + divisao);
        }
    }
}
