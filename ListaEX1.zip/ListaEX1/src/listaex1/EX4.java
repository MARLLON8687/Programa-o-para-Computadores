/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;


import java.util.Scanner;

public class EX4 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
       
        System.out.print("Digite o primeiro número inteiro: ");
        int num1 = scanner.nextInt();
        
       
        System.out.print("Digite o segundo número inteiro: ");
        int num2 = scanner.nextInt();
        
      
        if (num1 > num2) {
            System.out.println("O primeiro número é maior que o segundo.");
        } else if (num1 < num2) {
            System.out.println("O primeiro número é menor que o segundo.");
        } else {
            System.out.println("Os dois números são iguais.");
        }
        
   
    }
}
