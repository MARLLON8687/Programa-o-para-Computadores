/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;

import java.util.Scanner;

public class EX6 {
    public static void main(String[] args) {
  
        Scanner scanner = new Scanner(System.in);

   
        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt();


        System.out.println("Número: " + numero);
        System.out.println("Elevado a 2: " + Math.pow(numero, 2));
        System.out.println("Elevado a 4: " + Math.pow(numero, 4));
        System.out.println("Elevado a 6: " + Math.pow(numero, 6));
        System.out.println("Elevado a 8: " + Math.pow(numero, 8));
        System.out.println("Elevado a 10: " + Math.pow(numero, 10));

 
    }
}