/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;

import java.util.Scanner;

public class EX7 {
    public static void main(String[] args) {
  
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número: ");
        int num1 = scanner.nextInt();
        
        System.out.print("Digite o segundo número: ");
        int num2 = scanner.nextInt();

        System.out.println("Comparando os números " + num1 + " e " + num2 + ":");
        System.out.println(num1 + " é maior que " + num2 + "? " + (num1 > num2));
        System.out.println(num1 + " é menor que " + num2 + "? " + (num1 < num2));
        System.out.println(num1 + " é igual a " + num2 + "? " + (num1 == num2));
        System.out.println(num1 + " é diferente de " + num2 + "? " + (num1 != num2));


    }
}