/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;

import java.util.Scanner;

public class EX8 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Digite o valor do relógio de água no dia 1º do mês (em litros): ");
        int valorDia1 = scanner.nextInt();

        
        System.out.print("Digite o valor do relógio de água no dia 30 do mês (em litros): ");
        int valorDia30 = scanner.nextInt();

       
        int consumoTotal = valorDia30 - valorDia1;

        
        double mediaDiaria = (double) consumoTotal / 30;

        
        System.out.println("Consumo total de água no mês: " + consumoTotal + " litros");
        System.out.println("Média diária de consumo: " + mediaDiaria + " litros");

        
       
    }
}
