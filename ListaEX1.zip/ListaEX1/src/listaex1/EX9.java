/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listaex1;
import java.util.Scanner;

public class EX9 {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt();

        
        if (numero > 10 && numero < 100) {
            
            double potencia = Math.pow(numero, 2);
            
            System.out.printf("Número elevado a 2: %.5f\n", potencia);
        } else {
            
            double raizQuadrada = Math.sqrt(numero);
            
            System.out.printf("Raiz quadrada: %.5f\n", raizQuadrada);
        }

        
      
    }
}